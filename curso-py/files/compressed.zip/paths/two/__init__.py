def init(db, api, **others):
    print(f"I'm package two: {db} {api}")
