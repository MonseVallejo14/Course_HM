def init(graphql, **others):
    print(f"I'm package one: {graphql}")
