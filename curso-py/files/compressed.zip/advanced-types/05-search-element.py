pets = ["Murphy", "Cleo", "Zofy", "Mía", "Freyja",
        "Murphy", "Tortilla", "Wally", "Coco"]

print(pets.count("Murphy"))  # How many times there is an element in the list
if "Murphy" in pets:
    print(pets.index("Murphy"))  # Get us the number of the element in the list
