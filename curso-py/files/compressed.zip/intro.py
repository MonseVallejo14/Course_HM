"""Module providing a function printing python version."""

print("Hola mundo!")
print("El weta " * 4)
