variable_1 = "My first variable"
print(variable_1)
