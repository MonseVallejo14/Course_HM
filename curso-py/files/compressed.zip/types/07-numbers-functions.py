import math

print(round(1.2))
print(abs(-123))
print(round(3.8))

print(math.isnan(65))
print(math.fabs(-123))
print(math.isqrt(64))
