variable_1 = "My first variable"
descripcion = """I'm learning Python, 
and I'm learning it now.
"""
print(variable_1, descripcion)
print(len(variable_1))
print(variable_1[14])
print(variable_1[3:8])
