# This symbol is for comment
# \ This symbol is so that the following isn't taken as part of the code, for example:
# \'
# \"
# \\
# \n This symbol is to move the following to a new line

course = "Ulimate \"Python\""
print(course)
