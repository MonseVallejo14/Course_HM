name = "Murphy"
lastname = "Vallejo"
full_name = name + " " + lastname
full_name2 = f"{name} {lastname}"
print(full_name2)
