from users.taxes.utilities import paying_taxes
# import users
paying_taxes()
# print(__name__)
# print(dir(users))
# print(users.__name__)
# print(users.__file__)
# print(users.__package__)
# print(users.__path__)
