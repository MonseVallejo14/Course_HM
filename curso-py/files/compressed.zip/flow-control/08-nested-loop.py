for j in range(5):
    for k in range(4):
        print(f"{j}, {k}")
