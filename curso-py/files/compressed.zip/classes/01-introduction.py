# Class = Construction plan
# Object = Instance of a class

# Examples:
# Class = Construction plan of a house
# Object = Built house

# Class = Human
# Object = Beto, Keity, Monse...

message = "Hello world"
print(type(message))
