def long(text):
    result = 0
    for _ in text:
        result += 1
    return result


print("Hello World")
l = long("Hello Murphy")
print(l)
