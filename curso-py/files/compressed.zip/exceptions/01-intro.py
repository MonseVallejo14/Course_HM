try:
    n1 = int(input("Enter the first number: "))
except:
    print("An error ocurred :(")
