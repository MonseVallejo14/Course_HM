try:
    n1 = int(input("Enter the first number: "))
    dmhgfhj
except ValueError as e:
    print("Enter a numeric value please")

except NameError as es:
    print("An error ocurred!")
